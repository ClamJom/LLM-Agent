import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
import skfuzzy as fuzz
import matplotlib
matplotlib.use('TkAgg')

# 加载鸢尾花数据集
iris = datasets.load_iris()
data = iris.data

# 设置模糊C均值聚类的参数
n_clusters = 3  # 聚类数目
max_iter = 100  # 最大迭代次数
fuzziness = 2.0  # 模糊度

# 运行模糊C均值聚类算法
cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(data.T, n_clusters, m=fuzziness, error=0.005, maxiter=max_iter, init=None)

# 获取最大隶属度的聚类标签
cluster_labels = np.argmax(u, axis=0)

# 绘制聚类图
colors = ['r', 'g', 'b']
for i in range(n_clusters):
    cluster_points = data[cluster_labels == i]
    plt.scatter(cluster_points[:, 0], cluster_points[:, 1], c=colors[i], label=f'Cluster {i+1}')
    plt.plot(cntr[i][0], cntr[i][1], 'k*', markersize=10, c=colors[i])

plt.xlabel('Sepal length')
plt.ylabel('Sepal width')
plt.title('Fuzzy C-means Clustering of Iris Dataset')
plt.legend()
plt.show()
