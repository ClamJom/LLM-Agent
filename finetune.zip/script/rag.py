import numpy as np
import sqlite3
import json
import os
import re

from transformers import AutoTokenizer
from llama_cpp import Llama
from sklearn.cluster import KMeans
from sklearn.preprocessing import Normalizer
from json import JSONEncoder

from setting import settings, prompt
from common.models import OpenAi

class SearchNode:
    def __init__(self, data: np.ndarray):
        self.data = data
        self.childList: list[SearchNode] | None = None
        self.des = None
        self.start_line = -1
        self.end_line = -1
    
    def get_dis(self, x: np.ndarray):
        # 使用余弦距离（即相关性）
        _x = np.dot(self.data, x)
        _y = np.dot(np.linalg.norm(self.data), np.linalg.norm(x))
        return _x / _y

class SearchNodeEncoder(JSONEncoder):
    def default(self, o):
        return o.__dict__
    
class RAGTreeDB:
    # RAG搜索树数据库对象，封装对树形RAG搜索的操作
    def __init__(self, file_name):
        self.path = settings.RAG_SQLITE_DATABASE_PATH
        self.create_rag_vector_database()
        self.name = file_name
    
    def create_rag_vector_database(self):
        conn = sqlite3.connect(self.path, check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute(
            """CREATE TABLE IF NOT EXISTS rag_vector(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_name TEXT,
                start_line INTEGER,
                end_lie INTEGER,
                vector TEXT,
                des TEXT,
                parent_id INTEGER
            )
            """
        )
        conn.commit()
        conn.close()
    
    def get_node_id(self, node: SearchNode):
        # 获取节点的ID
        conn = sqlite3.connect(self.path, check_same_thread=False)
        cursor = conn.cursor()
        res = cursor.execute(
            """SELECT id FROM rag_vector WHERE vector = ?""", (json.dumps(node.data))
        )
        current_data = res.fetchone()
        conn.close()
        return current_data[0] if current_data else None
    
    def save_search_tree(self, root: SearchNode, parent_id: int = -1):
        if root is None:
            return
        conn = sqlite3.connect(self.path, check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO rag_vector(file_name, start_line, end_line, vector, des, parent_id) VALUES (?, ?, ?, ?, ?, ?)""",
            (
                self.name,
                root.start_line,
                root.end_line,
                json.dumps(root.data),
                root.des,
                parent_id,
            )
        )
        conn.commit()
        new_parent_id = cursor.lastrowid
        conn.close()
        if root.childList is None:
            return
        for child in root.childList:
            self.save_search_tree(child, new_parent_id)

    def __load_tree_with_parent_id(self, parent_id: int):
        conn = sqlite3.connect(self.path, check_same_thread=False)
        cursor = conn.cursor()
        result = cursor.execute("SELECT * FROM rag_vector WHERE parent_id = ?", (parent_id,))
        node_list = []
        for row in result:
            node = SearchNode(json.loads(row[4]))
            node.des = row[5]
            node.start_line = row[2]
            node.end_line = row[3]
            node.childList = self.__load_tree_with_parent_id(row[0])
            if node.childList is None:
                node.childList = []
            node_list.append(node)
        conn.close()
        return node_list
    
    def get_root_nodes(self):
        # 获取所有搜索树的根节点
        conn = sqlite3.connect(self.path, check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute(
            """SELECT * FROM rag_vector WHERE parent_id is -1"""
        )
        result = cursor.fetchall()
        conn.close()
        node_list = []
        for row in result:
            node = SearchNode(json.loads(row[4]))
            node.des = row[5]
            node.start_line = row[2]
            node.end_line = row[3]
            node_list.append(node)
        return node_list

    def load_search_tree(self, id: int):
        # 通过ID加载搜索树
        conn = sqlite3.connect(self.path, check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute(
            """SELECT * FROM rag_vector WHERE id=?""", (id,)
        )
        node = cursor.fetchone()
        if node is None:
            return None
        root = SearchNode(json.loads(node[4]))
        root.des = node[5]
        root.childList = self.__load_tree_with_parent_id(id)
        return root
    
    def search_tree(self, root: SearchNode, query_vector: np.ndarray):
        # 搜索树
        if not root.childList:
            return root.des
        minDis = float("inf")
        nearestChild = None
        for i in range(len(root.childList)):
            if root.childList[i].get_dis(query_vector) < minDis:
                minDis = root.childList[i].get_dis(query_vector)
                nearestChild = root.childList[i]
        return self.search_tree(nearestChild, query_vector)

class RAGTree:
    # 待完善.....
    def __init__(self, file_name: str):
        self.file_path = os.path.join(settings.RAG_UPLOAD_PATH, file_name)
        self.file_name = file_name
        self.rag_db = RAGTreeDB(file_name)
        self.tokenizer = AutoTokenizer.from_pretrained(settings.RAG_TOKENIZER_PATH_OR_NAME)
        self.max_token = settings.RAG_N_CTX
    
    def __split_sentences(self, text):
        # 通过标点分割句子
        sentences = re.split(r"(?<=[。！？. ? !])", text)
        return [s.strip() for s in sentences if s.strip()]
    
    def chunk_text(self, text):
        # 将文本按照每块最大`self.max_token`分割，并保持其中的句子完整性
        sentences = self.__split_sentences(text)
        chunks = []
        current_chunk = []
        current_token_count = 0

        for sentence in sentences:
            sentence_tokens = self.tokenizer.encode(sentence, add_special_tokens=False)
            sentence_token_count = len(sentence_tokens)

            if current_token_count + sentence_token_count > self.max_token:
                # 当前块已满，保存并重置
                chunks.append(" ".join(current_chunk))
                current_chunk = [sentence]
                current_token_count = sentence_token_count
            else:
                # 继续填充当前块
                current_chunk.append(sentence)
                current_token_count += sentence_token_count

        # 添加最后一个块
        if current_chunk:
            chunks.append(" ".join(current_chunk))

        return chunks