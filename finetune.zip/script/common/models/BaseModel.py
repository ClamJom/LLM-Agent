class BaseModel:
    """
    基础模型
    --------------
    一开始是想写成像C++那样的面向对象.....
    """

    def __init__(self):
        pass

    def __call__(self, *args, **kwargs):
        pass

    def setting(self, *args, **kwargs):
        pass
