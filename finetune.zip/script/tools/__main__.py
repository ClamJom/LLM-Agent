from tools import internet_search


if __name__ == "__main__":
    print(internet_search("python"))
