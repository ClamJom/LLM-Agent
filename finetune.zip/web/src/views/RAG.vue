<script>
import CSlider from "@/components/CSlider.vue";
import axios from 'axios';
import { MdPreview, MdEditor } from 'md-editor-v3';
import { fetchEventSource } from '@microsoft/fetch-event-source';
import 'md-editor-v3/lib/style.css'

export default{
    components:{
        CSlider,
        MdPreview,
        MdEditor
    },
    data(){
        return{
            settings:{
                model: "Qwen/Qwen2.5-32B-Instruct",
                systemPrompt: "你是一个智能客服，回答用户的各项问题。如果用户的问题与某些文件相关，这里会附上相关的信息，请总结其中的信息并根据你已有的知识回复用户相关问题。",
                // 温度，记得用Slider值除以100
                temperature: 70,
                // 搜索文档相关性最高的前top_k个上下文
                top_k: 4,
                // 默认流式传输
                // stream: true
            },
            // 各种状态
            status:{
                drawer: true,
                // 是否正在生成
                generating: false,
                // 流式传输终止信号
                abortSignal: null,
            },
            // 模型列表
            modelList: ["Qwen/Qwen2.5-32B-Instruct", "M1", "M2", "M2"],
            // 消息
            message: "",
            // 消息列表
            messages: [{
                role: "user",
                content: "你好",
                timestamp: new Date().toLocaleString()
            },{
                role: "assistant",
                content: "你好，有什么可以帮到你的吗？",
                timestamp: new Date().toLocaleString(),
                // 关联文本上下文搜索结果
                contextSearchResult:[{
                    fileName: "TestFileName",
                    url: "",
                    contextChunk: {
                        start: 1,
                        end: 13,
                        context: "Test Context",
                        relative: 0.6   // 相关性
                    }
                }],
            }],
            // 当前文件处理进度，储存文件向量化进度
            currentFileHandleProgress:{
                fileName: "",
                progress: 0
            },
            fileList: [{
                fileName: "test_file.txt",
                fileType: "file/text"
            },{
                fileName: "test_file.txt",
                fileType: "file/text"
            },{
                fileName: "test_file.txt",
                fileType: "file/text"
            }]
        }
    },
    methods:{
        handleInputKeyDown(e){
            if(!e.shiftKey && e.keyCode === 13){
                e.preventDefault();
                // 发送消息
            }
        }
    }
}
</script>

<template>
<div class="body">
    <Transition name="drawer">
    <div class="left_bar" v-if="status.drawer">
        <div class="left_bar_header">
            <div class="file_list_header">文件</div>
            <div class="file_list">
                <div class="file_item" v-for="(file, idx) of fileList" :key="idx">
                    <div class="file_preview">
                        <img :src="'/api/download_file/' + file.fileName"
                         :alt="file.fileName"
                         v-if="file.fileType.indexOf('image') != -1">
                    </div>
                    <div class="file_name">{{file.fileName}}</div>
                </div>
                <div class="file_item">
                    <div class="file_preview">
                        <!-- 上传图标 -->
                    </div>
                    <div class="file_name">上传文件</div>
                </div>
            </div>
        </div>
        <div class="left_bar_body">
            <div class="settings">
                <div class="setting_item">
                    <div class="setting_title">模型</div>
                    <div class="setting_body">
                        <select v-model="settings.model" name="model" id="model">
                            <option v-for="(model, idx) of modelList" :key="idx" :value="model">{{ model }}</option>
                        </select>
                    </div>
                </div>
                <div class="setting_item">
                    <div class="setting_title">系统提示词</div>
                    <div class="setting_body">
                        <textarea 
                        :value="settings.systemPrompt" 
                        name="system_prompt" 
                        id="system_prompt"
                        rows="5"
                        style="resize: none; width: calc(100% - 5px);">
                        </textarea>
                    </div>
                </div>
                <div class="setting_item">
                    <div class="setting_title">温度</div>
                    <div class="setting_body">
                        <CSlider v-model="settings.temperature"
                        :min="10" 
                        :max="100"
                        :caster="(value)=>{return (value / 100).toFixed(2);}">
                        </CSlider>
                    </div>
                </div>
                <div class="setting_item">
                    <div class="setting_title">最匹配的N个结果</div>
                    <div class="setting_body">
                        <CSlider v-model="settings.top_k"
                        :min="1" 
                        :max="10">
                        </CSlider>
                    </div>
                </div>
                <div class="setting_item">
                    <div class="setting_title">测试</div>
                    <div class="setting_body">
                        <button @click="status.drawer = !status.drawer">测试</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </Transition>
    <div class="main">
        <div class="chat_container">
            <div class="chat_title">
                <h3>RAG测试</h3>
            </div>
            <TransitionGroup name="message">
                <div class="message" v-for="(message, idx) of messages" :key="idx" :class="message.role">
                    <div class="message_header">{{ message.timestamp }}</div>
                    <div class="message_body">
                        <MdPreview v-model="message.content"></MdPreview>
                        <div class="message_foot">
                            <!-- 参考搜索的上下文结果 -->
                            <div class="relative_list" v-if="message.role === 'assistant' && message.contextSearchResult">
                                <div class="relative_title">参考文件</div>
                                <div class="relative_item" v-for="(relative, idx) of message.contextSearchResult" :key="idx">
                                    <div class="related_file_name">{{ relative.fileName }}</div>
                                    <div class="lines">
                                        行：
                                        <span>{{ relative.contextChunk.start }}</span>
                                        -
                                        <span>{{ relative.contextChunk.end }}</span>
                                    </div>
                                    <div class="correlation_rate">相关率：{{ relative.contextChunk.relative }}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </TransitionGroup>
        </div>
        <div class="message_send_box">
            <div class="message_send_header">
            </div>
            <div class="message_send_body">
                <textarea 
                    name="send_message" 
                    id="send_message" 
                    placeholder="请输入消息....."
                    class="message_inputer"
                    v-model="message"
                    @keydown="handleInputKeyDown">
                </textarea>
            </div>
        </div>
    </div>
</div>
</template>

<style scoped>
@import url("../assets/rag.css");

.drawer-enter-active,
.drawer-leave-active {
    transition: all 0.5s ease-in-out;
}

.drawer-enter-from,
.drawer-leave-to{
    transform: translateX(-100%);
    opacity: 0;
}

.message-enter-active,
.message-leave-active {
    transition: all 0.3s;
}

.message-enter-from,
.message-leave-to {
    opacity: 0;
}
</style>